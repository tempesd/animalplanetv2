package com.animalplanet.animalplanet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimalplanetApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimalplanetApplication.class, args);
	}

}
